# Shopfront

An AI agent that writes a brand kit, website and ads for small businesses — and keeps them updated.

## What's in here

- `index.html` — the whole site (front end). Businesses are saved in each visitor's own browser.
- `api/generate.js` — a small server function that holds your Anthropic API key and forwards requests to Claude. The key never reaches the browser.
- `vercel.json` — lets website generation run up to 5 minutes.

## Put it online (Vercel, free tier works)

1. Get an API key at https://console.anthropic.com → API Keys. Add a few dollars of credit, and **set a monthly spend limit** under Limits.
2. Make a free GitHub account, create a new repository, and upload these files (keep the `api` folder).
3. Go to https://vercel.com, sign in with GitHub, choose **Add New → Project**, and import the repository.
4. Before deploying, open **Environment Variables** and add:
   - `ANTHROPIC_API_KEY` = your key
   - `ACCESS_CODE` = any password you choose (strongly recommended — without it, anyone who finds the site spends your credits)
5. Click **Deploy**. You'll get a link like `shopfront-yourname.vercel.app`. Add your own domain under Settings → Domains if you want.

To change the key or code later, edit the variables in Vercel and redeploy.

## Costs

Each full generation (brand kit + ads + website) is one to a few dimes of API usage depending on the model; updates cost less. Your spend limit in the Anthropic Console is the hard cap.

## Optional settings

- `MODEL` — model for brand kits, ads and websites (default `claude-sonnet-5`)
- `QUICK_MODEL` — model for figuring out what an update touches (default `claude-haiku-4-5-20251001`)

## Data

Each visitor's businesses live in their own browser's storage. **Export backup** in the sidebar downloads everything as a file; **Import** restores it on another device or browser.
